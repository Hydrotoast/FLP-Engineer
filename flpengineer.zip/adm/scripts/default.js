$(function() {
	$("#add_site_btn").colorbox({href: "forms/add_site.html"});
	$("#add_user_btn").colorbox({href: "forms/add_user.html"});
});