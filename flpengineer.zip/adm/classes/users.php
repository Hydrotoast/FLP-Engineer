<?php
require 'db.php';

class Users
{
	function register($username, $password)
	{
		$db = new Database();
		$check_login = $db->check_username($username);
		
		if($check_login)
		{
			die($lang['USERNAME_EXISTS']);
		}
		else
		{
			$db->add_user($username, $password);
		}
	}
	
	function login($username, $password)
	{
		$db = new Database(); //Instantiate the database
		$check_login = $db->check_login($username, $password); //Check login details
		
		//Results of login
		if($check_login)
		{
			//Set our session
			$_SESSION['logged'] = TRUE;
			$db->log($_SERVER['REMOTE_ADDR']);
			return true;
		} 
		else 
		{
			//Return login fail
			return false;
		}
	}
	
	function logout()
	{	
		if(isset($_SESSION['logged']))
		{
			//Kill session
			unset($_SESSION['logged']);
			$my_cookie = $_COOKIE[session_name()];
			
			//Remove cookies
			if(isset($my_cookie))
			{
				setcookie(session_name(), '', time() - 9999);
				session_destroy();
			}
		}
	}
}