<?php

require_once '../config.php';

class Database
{
	private $db; //Set to private variable
	private $salt = 'cynosura';
	
	function Database()
	{
		$this->db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME) or die('Error connection to database. \n');
	}
	
	function log($ip)
	{
		$query = 'INSERT INTO ' . DB_EXT . '_logs (log_ip, log_time) VALUES (?, ?)';
		$stmt = $this->db->prepare($query);
		
		if($stmt)
		{
			$stmt->bind_param('sd', $ip, time());
			$stmt->execute();
			$stmt->close();
		}

		$this->db->close();
	}

	function check_username($username)
	{
		$qusername = $this->db->real_escape_string($username);
		$query = 'SELECT * FROM ' . DB_EXT . '_admins WHERE admin_user=' . $qusername;
		$result = $this->db->query($query);
		
		if($result->num_rows > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
		
		$result->free_result();
		$this->db->close();
	}
	
	function check_login($username, $password)
	{
		//Escape the strings to prevent SQL injections
		$qusername = $this->db->real_escape_string($username);
		$qpassword = base64_encode($this->db->real_escape_string($password) . $this->salt);
		
		$query = 'SELECT * FROM ' . DB_EXT . '_admins WHERE admin_user = ? AND admin_pass = ? LIMIT 1'; //Construct query
		$stmt = $this->db->prepare($query); //Prepare the query
		
		if($stmt)
		{
			$stmt->bind_param('ss', $qusername, $qpassword); //Bind variables into strings where '?' is.
			$stmt->execute(); //Rebuild string with bound variables
			$result = $stmt->fetch(); //Check for query success
			
			return ($result) ? true : false;
			$result->free_result();
			$stmt->close(); //End SQL queries
		}
		
		$this->db->close();
	}
	
	function add_user($username, $password)
	{
		//Escape the strings to prevent SQL injections
		$qusername = $this->db->real_escape_string($username);
		$qpassword = base64_encode($this->db->real_escape_string($password) . $this->salt);
		
		$query = 'INSERT INTO ' . DB_EXT . '_admins (admin_user, admin_pass, admin_join) VALUES (?, ?, ?)'; //Construct query
		$stmt = $this->db->prepare($query); //Prepare the query
		
		if($stmt)
		{
			$stmt->bind_param('ssd', $qusername, $qpassword, time()); //Bind variables into strings where '?' is.
			$stmt->execute(); //Rebuild string with bound variables
			$stmt->close(); //End SQL queries
		}
		
		$this->db->close();
	}
	
	function get_active_flp()
	{
		$query = 'SELECT config_value FROM ' . DB_EXT . '_config WHERE config_key=\'active_flp\' LIMIT 1';
		$result = $this->db->query($query);
		
		return $result;
		$result->free_result();
		$this->db->close();
	}
	
	function activate_flp($file)
	{
		if(!is_dir($file))
		{
			$file = $this->db->real_escape_string($file);
			$query = 'UPDATE ' . DB_EXT . '_config SET config_value=\'' . $file . '\' WHERE config_key=\'active_flp\'';
			$this->db->query($query);
			$this->db->close();
		}
	}
	
	function get_logs()
	{
		$query = 'SELECT * FROM ' . DB_EXT . '_users ORDER BY user_id DESC';
		$result = $this->db->query($query);
		
		return $result;
		$result->free_result();
		$this->db->close();
	}
	
	function delete_logs($ids)
	{
		$query = '';
		foreach($ids as $id)
		{
			$query .= 'DELETE FROM ' . DB_EXT . '_users WHERE user_id=' . $id . ';';
		}
		
		$this->db->multi_query($query);
		$this->db->close();
	}
	
	function get_sites()
	{
		$query = 'SELECT * FROM ' . DB_EXT . '_sites ORDER BY site_id DESC';
		$result = $this->db->query($query);
		
		return $result;
		$result->free_result();
		$this->db->close();
	}
	
	function activate_site($id)
	{
		$query = 'UPDATE ' . DB_EXT . '_sites SET site_active=0 WHERE site_active=1;';
		$query .= 'UPDATE ' . DB_EXT . '_sites SET site_active=1 WHERE site_id=' . $id . ';';
		$this->db->multi_query($query);
		$this->db->close();
	}
	
	
	function add_site($redirect)
	{
		$redirect = filter_var($redirect, FILTER_SANITIZE_URL);
		$query = 'INSERT INTO ' . DB_EXT . '_sites (site_redirect) VALUES (\'' . $redirect . '\')';
		$this->db->query($query);
		$this->db->close();
	}
	
	function delete_site($id)
	{
		$id = filter_var($id, FILTER_SANITIZE_NUMBER_INT);
		$query = 'DELETE FROM ' . DB_EXT . '_sites WHERE site_id=' . $id;
		$this->db->query($query);
		$this->db->close();
	}
}