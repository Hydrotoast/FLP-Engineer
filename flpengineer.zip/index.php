<?php 
include "config.php";
$db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME) or die('Error connection to database. \n');

$query = 'SELECT config_value FROM ' . DB_EXT . '_config WHERE config_key=\'active_flp\'';
$result = $db->query($query);

while($row = $result->fetch_assoc())
{
	$active_flp = $row['config_value'];
}

$result->free_result();
$db->close();

if(is_dir($active_flp))
{
	$active_flp = 'plain.html';
}

include 'lang/' . LOCALISATION . '.php';
include 'template/header.php';
include 'flps/' . $active_flp;
include 'template/footer.php'; 
?>