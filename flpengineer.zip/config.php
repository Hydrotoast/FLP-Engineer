<?php
DEFINE('DB_HOST', 'localhost');
DEFINE('DB_USER', 'root');
DEFINE('DB_PASS', '');
DEFINE('DB_NAME', 'gaia_flp');
DEFINE('DB_EXT', 'flp');

DEFINE('LOCALISATION', 'en');
?>